/* Editable project handoff. Runs entirely in the browser without a server. */
(function () {
  'use strict';
  const encoder = new TextEncoder();
  const crcTable = Uint32Array.from({ length: 256 }, (_, value) => {
    for (let i = 0; i < 8; i++) value = (value >>> 1) ^ ((value & 1) ? 0xedb88320 : 0);
    return value >>> 0;
  });
  function crc32(bytes) {
    let crc = 0xffffffff;
    for (const byte of bytes) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8);
    return (crc ^ 0xffffffff) >>> 0;
  }
  function safePath(name) {
    if (!name || /[\\:\x00-\x1f\x7f]/.test(name)
      || name.split('/').some(part => !part || part === '.' || part === '..')) {
      throw new Error('Cannot package this filename: ' + name + '. Rename the image and update its ArchieML path.');
    }
    return name;
  }
  function imageBytes(url, name) {
    const match = /^data:image\/[^;,]+;base64,([A-Za-z0-9+/=\r\n]*)$/.exec(url);
    if (!match) throw new Error('Could not package ' + name + '. Add the local image again.');
    const binary = window.atob(match[1]);
    return Uint8Array.from(binary, character => character.charCodeAt(0));
  }
  function scriptData(globalName, value) {
    return 'window.' + globalName + ' = ' + JSON.stringify(value).replace(/</g, '\\u003c') + ';\n';
  }
  // Read the data files in a project. Never evaluate editor-data.js or any
  // archived application code; the currently open editor remains in control.
  async function readProject(file) {
    const limit = 256 * 1024 * 1024;
    if (file.size > limit) throw new Error('This ZIP is larger than 256 MB. Use a smaller project ZIP.');
    const bytes = new Uint8Array(await file.arrayBuffer());
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const text = new TextDecoder('utf-8', { fatal: true });
    const bad = () => { throw new Error('This ZIP is incomplete or damaged. Download the project again.'); };
    const within = (offset, length, end = bytes.length) => {
      if (offset < 0 || length < 0 || offset + length > end) bad();
    };
    // Locate the final directory record, allowing a standard ZIP comment.
    let end = -1;
    for (let at = bytes.length - 22; at >= Math.max(0, bytes.length - 65557); at--) {
      if (view.getUint32(at, true) === 0x06054b50
        && at + 22 + view.getUint16(at + 20, true) === bytes.length) { end = at; break; }
    }
    if (end < 0) bad();
    const count = view.getUint16(end + 10, true);
    const directorySize = view.getUint32(end + 12, true);
    const directoryStart = view.getUint32(end + 16, true);
    if (view.getUint16(end + 4, true) || view.getUint16(end + 6, true)
      || view.getUint16(end + 8, true) !== count || count === 65535
      || directorySize === 0xffffffff || directoryStart === 0xffffffff) {
      throw new Error('Use a standard, single ZIP from Download all files. Split ZIPs and ZIP64 are not supported.');
    }
    if (count > 4096) throw new Error('This ZIP contains too many files. Choose one graphic project.');
    within(directoryStart, directorySize, end);
    const directoryEnd = directoryStart + directorySize;
    const entries = new Map();
    let at = directoryStart, expanded = 0;
    for (let index = 0; index < count; index++) {
      within(at, 46, directoryEnd);
      if (view.getUint32(at, true) !== 0x02014b50) bad();
      const flags = view.getUint16(at + 8, true);
      const method = view.getUint16(at + 10, true);
      const crc = view.getUint32(at + 16, true);
      const packed = view.getUint32(at + 20, true);
      const size = view.getUint32(at + 24, true);
      const nameLength = view.getUint16(at + 28, true);
      const extraLength = view.getUint16(at + 30, true);
      const commentLength = view.getUint16(at + 32, true);
      const local = view.getUint32(at + 42, true);
      if ((flags & 0x0041) || view.getUint16(at + 34, true)) throw new Error('Password-protected or split ZIPs cannot be opened. Use Download all files again.');
      if ([packed, size, local].includes(0xffffffff)) throw new Error('ZIP64 files cannot be opened. Use a smaller project ZIP.');
      within(at + 46, nameLength + extraLength + commentLength, directoryEnd);
      const name = text.decode(bytes.subarray(at + 46, at + 46 + nameLength));
      const directory = name.endsWith('/');
      safePath(directory ? name.slice(0, -1) : name);
      if (entries.has(name)) throw new Error('This ZIP has duplicate filenames. Download one complete project again.');
      const attributes = view.getUint32(at + 38, true);
      if (((attributes >>> 16) & 0xf000) === 0xa000) throw new Error('This ZIP contains a file shortcut. Include the actual image files instead.');
      expanded += size;
      if (expanded > limit) throw new Error('The files in this ZIP exceed 256 MB when opened. Use a smaller project.');
      within(local, 30, directoryStart);
      if (view.getUint32(local, true) !== 0x04034b50
        || view.getUint16(local + 6, true) !== flags || view.getUint16(local + 8, true) !== method) bad();
      const localNameLength = view.getUint16(local + 26, true);
      const localExtraLength = view.getUint16(local + 28, true);
      const start = local + 30 + localNameLength + localExtraLength;
      within(local + 30, localNameLength + localExtraLength, directoryStart);
      if (text.decode(bytes.subarray(local + 30, local + 30 + localNameLength)) !== name) bad();
      within(start, packed, directoryStart);
      entries.set(name, { name, method, crc, packed, size, start, directory });
      at += 46 + nameLength + extraLength + commentLength;
    }
    if (at !== directoryEnd) bad();
    const sources = [...entries.values()].filter(entry => !entry.directory
      && !entry.name.startsWith('__MACOSX/') && /(^|\/)content\.aml$/.test(entry.name));
    if (sources.length !== 1) throw new Error('Choose a ZIP containing one content.aml, its design files and images. Use Download all files to create it.');
    const prefix = sources[0].name.slice(0, -'content.aml'.length);
    for (const name of ['styles.css', 'template.html']) {
      if (!entries.has(prefix + name)) throw new Error('This project is missing ' + name + '. Download all files again from the original editor.');
    }
    async function unpack(entry) {
      let result;
      const compressed = bytes.subarray(entry.start, entry.start + entry.packed);
      if (entry.method === 0) result = compressed;
      else if (entry.method === 8) {
        let decompressor;
        try { decompressor = new DecompressionStream('deflate-raw'); }
        catch { throw new Error('This browser cannot open a recompressed ZIP. Use a current browser or the original ZIP from Download all files.'); }
        const reader = new Blob([compressed]).stream().pipeThrough(decompressor).getReader();
        const chunks = [];
        let length = 0;
        try {
          while (true) {
            const chunk = await reader.read();
            if (chunk.done) break;
            length += chunk.value.length;
            if (length > entry.size || length > limit) { await reader.cancel(); bad(); }
            chunks.push(chunk.value);
          }
        } catch { bad(); }
        finally { reader.releaseLock(); }
        result = new Uint8Array(length);
        let offset = 0;
        for (const chunk of chunks) { result.set(chunk, offset); offset += chunk.length; }
      } else throw new Error('This ZIP uses an unsupported compression format. Use the original ZIP from Download all files.');
      if (result.length !== entry.size || crc32(result) !== entry.crc) bad();
      return result;
    }
    const readText = async name => text.decode(await unpack(entries.get(prefix + name)));
    const aml = await readText('content.aml');
    const styles = await readText('styles.css');
    const template = await readText('template.html');
    const mime = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', avif: 'image/avif', bmp: 'image/bmp', ico: 'image/x-icon', tif: 'image/tiff', tiff: 'image/tiff' };
    const images = new Map();
    for (const entry of entries.values()) {
      if (entry.directory || !entry.name.startsWith(prefix + 'images/')) continue;
      const type = mime[entry.name.split('.').pop().toLowerCase()];
      if (!type) continue;
      const contents = await unpack(entry);
      const parts = [];
      for (let offset = 0; offset < contents.length; offset += 32768) {
        parts.push(String.fromCharCode(...contents.subarray(offset, offset + 32768)));
      }
      images.set(entry.name.slice(prefix.length), 'data:' + type + ';base64,' + window.btoa(parts.join('')));
    }
    return { aml, styles, template, images };
  }
  // ZIP32, STORE method, UTF-8 filenames and CRC32 per PKWARE APPNOTE 6.3.10.
  // Images are already compressed; STORE also works without browser codecs.
  function zip(entries) {
    if (entries.length >= 65535) throw new Error('Too many files to download together.');
    const locals = [], central = [];
    let offset = 0, directorySize = 0;
    const now = new Date();
    const year = Math.max(1980, Math.min(2107, now.getFullYear()));
    const date = ((year - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
    const time = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);
    const names = new Set();
    for (const [name, contents] of entries) {
      safePath(name);
      if (names.has(name)) throw new Error('Duplicate filename in project: ' + name);
      names.add(name);
      const filename = encoder.encode('text-messages-project/' + name);
      const bytes = typeof contents === 'string' ? encoder.encode(contents) : contents;
      if (filename.length > 65535 || bytes.length >= 0xffffffff) throw new Error('A project file is too large to package.');
      const crc = crc32(bytes);
      const local = new Uint8Array(30 + filename.length);
      const l = new DataView(local.buffer);
      l.setUint32(0, 0x04034b50, true);
      l.setUint16(4, 20, true); l.setUint16(6, 0x0800, true);
      l.setUint16(10, time, true); l.setUint16(12, date, true);
      l.setUint32(14, crc, true); l.setUint32(18, bytes.length, true); l.setUint32(22, bytes.length, true);
      l.setUint16(26, filename.length, true); local.set(filename, 30);
      const directory = new Uint8Array(46 + filename.length);
      const d = new DataView(directory.buffer);
      d.setUint32(0, 0x02014b50, true);
      d.setUint16(4, 20, true); d.setUint16(6, 20, true); d.setUint16(8, 0x0800, true);
      d.setUint16(12, time, true); d.setUint16(14, date, true);
      d.setUint32(16, crc, true); d.setUint32(20, bytes.length, true); d.setUint32(24, bytes.length, true);
      d.setUint16(28, filename.length, true); d.setUint32(42, offset, true); directory.set(filename, 46);
      locals.push(local, bytes); central.push(directory);
      offset += local.length + bytes.length;
      directorySize += directory.length;
      if (offset + directorySize + 22 >= 0xffffffff) throw new Error('This project is too large to download as one ZIP.');
    }
    const end = new Uint8Array(22), e = new DataView(end.buffer);
    e.setUint32(0, 0x06054b50, true);
    e.setUint16(8, entries.length, true); e.setUint16(10, entries.length, true);
    e.setUint32(12, directorySize, true); e.setUint32(16, offset, true);
    return new Blob([...locals, ...central, end], { type: 'application/zip' });
  }
  const readme = `# Text messages — editable project

This folder contains the source, local images and design used when Download all files was clicked.

## Continue editing — no Node or installation

Recommended: open your team's /exec editor, click Open project ZIP, and select
this ZIP as downloaded. Source, local images and design load together; you do
not need to unzip it. This also works with ZIPs saved by editor version 1.4.

Alternatively, use the included local editor:

1. Extract the entire ZIP before opening any files.
2. Double-click editor.html. The saved text, images and design load automatically.
3. Edit and preview. Download HTML to produce the finished graphic.
4. Click Download all files again to save a new editable handoff with your changes.

Browser edits do not overwrite this folder automatically. Keep the newest ZIP.
Reopening this editor starts from the snapshot in this folder. Open ArchieML can
load a newer content.aml; new images can be added under Images and design files.

## Files

- content.aml: the full editable source, including comments and optional people.
- graphics_messages.html: the finished graphic, with local images embedded.
- images/: all bundled and imported local image files, including unused ones.
- styles.css and template.html: the current graphic design.
- editor.html and its support files: the browser editor with this saved project.
- vendor/: the bundled ArchieML parser and its licenses.

External image URLs and the web font still need an internet connection. To carry
a remote picture in the project, obtain its image file, add it in the editor,
and use its images/filename path in the ArchieML before downloading again.

## Working with a shared Google Doc

This ZIP is a snapshot. It does not sync changes to your Google Doc or a published
graphic. If your team uses a shared source Doc, keep that Doc up to date too.
The local editor does not directly import Google Docs. In your team's /exec
editor, Open project ZIP restores this saved source and all its local assets.
To use newer copy from a Google Doc, open the ZIP first, then Load from Google
Doc; the restored images and design stay available. Add any new images that
were introduced after this snapshot. Loading is read-only and never updates the Doc.
Share the Doc link separately; this ZIP does not include account or access settings.
After edits, download a fresh HTML and replace the published graphic in your CMS.
`;
  window.TextMessageProject = {
    read: readProject,
    pack({ aml, styles, template, images, html, editorFiles }) {
      if (!editorFiles || !editorFiles['editor.html']) throw new Error('The project download files did not load. Reopen the editor and try again.');
      const imageData = Object.fromEntries(images);
      const entries = [
        ['content.aml', aml], ['graphics_messages.html', html],
        ['styles.css', styles], ['template.html', template], ['README.md', readme],
        ...Object.entries(editorFiles),
        ['editor-files.js', scriptData('TextMessageEditorFiles', editorFiles)],
        ['editor-data.js', scriptData('TextMessageDefaults', { aml, styles, template, images: imageData, project: true })]
      ];
      for (const [name, url] of images) {
        safePath(name);
        if (!name.startsWith('images/')) throw new Error('Local images must use an images/ path.');
        entries.push([name, imageBytes(url, name)]);
      }
      return zip(entries);
    }
  };
})();
