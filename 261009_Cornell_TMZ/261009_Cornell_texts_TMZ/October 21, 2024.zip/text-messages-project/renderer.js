/* Shared renderer for the browser editor and optional Node builder. */
(function (factory) {
  const api = factory();
  // Hosted pages may expose CommonJS shims or a different globalThis object.
  // This renderer is a browser dependency whenever a browser window exists.
  if (typeof window !== 'undefined' && window.document) window.TextMessages = api;
  else if (typeof module === 'object' && module.exports) module.exports = api;
})(function () {
'use strict';
const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g,
  char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));

function fail(message) { throw new Error(message); }
function fields(object, allowed, location) {
  if (!object || typeof object !== 'object' || Array.isArray(object)) fail(`${location}: expected an object.`);
  for (const [key, value] of Object.entries(object)) {
    if (!allowed.includes(key)) fail(`${location}: unknown field "${key}". Check spelling or escape a colon inside multiline text.`);
    if (typeof value !== 'string') fail(`${location}.${key}: expected text.`);
  }
}
function assetPath(value, location) {
  if (!value) return '';
  if (/^https?:\/\//i.test(value)) {
    try { new URL(value); } catch { fail(`${location}: invalid image URL.`); }
    return value;
  }
  if (/^[a-z][a-z0-9+.-]*:/i.test(value) || value.startsWith('/') || value.includes('\\')
    || value.split('/').some(part => part === '..')) {
    fail(`${location}: use a relative images/ path or an https:// image URL.`);
  }
  return value.split('/').map(encodeURIComponent).join('/');
}

function render(data, resolveAsset = value => value) {
  const asset = (value, location) => {
    const normalized = assetPath(value, location);
    return normalized ? resolveAsset(normalized, location, value) : '';
  };
  const topFields = ['title', 'dek', 'note', 'source', 'notes', 'people', 'messages'];
  for (const key of Object.keys(data)) if (!topFields.includes(key)) fail(`Unknown top-level field "${key}".`);
  for (const key of ['title', 'dek', 'note', 'source', 'notes']) {
    if (data[key] !== undefined && typeof data[key] !== 'string') fail(`${key}: expected text.`);
  }
  if (!Array.isArray(data.people) || !data.people.length) fail('Add at least one person in [people].');
  if (!Array.isArray(data.messages) || !data.messages.length) fail('Add at least one item in [messages].');

  const people = new Map();
  for (const [i, person] of data.people.entries()) {
    const at = `Person ${i + 1}`;
    fields(person, ['id', 'name', 'side', 'headshot'], at);
    if (!/^[a-zA-Z][a-zA-Z0-9_-]*$/.test(person.id || '')) fail(`${at}: id must start with a letter and use only letters, numbers, - or _.`);
    if (people.has(person.id)) fail(`${at}: duplicate id "${person.id}".`);
    if (!person.name?.trim()) fail(`${at}: add a name.`);
    if (!['left', 'right'].includes(person.side)) fail(`${at}: side must be left or right.`);
    people.set(person.id, { ...person, headshot: asset(person.headshot, `${at} headshot`) });
  }

  const entries = data.messages.map((item, i) => {
    const at = `Message item ${i + 1}`;
    if (item.type === 'divider' || item.type === 'note') {
      fields(item, ['type', 'text'], at);
      if (!item.text?.trim()) fail(`${at}: add ${item.type} text.`);
      return item;
    }
    fields(item, ['type', 'person', 'group', 'time', 'text', 'image', 'image_alt', 'label'], at);
    if (item.type !== 'message') fail(`${at}: type must be message, divider or note.`);
    if (!people.has(item.person)) fail(`${at}: unknown person "${item.person || ''}". Match an id in [people].`);
    const group = item.group || 'solo';
    if (!['solo', 'start', 'middle', 'end'].includes(group)) fail(`${at}: group must be solo, start, middle or end.`);
    if (!item.text?.trim() && !item.image) fail(`${at}: add text or an image.`);
    if (item.image && !item.image_alt?.trim()) fail(`${at}: add image_alt to describe the attached image.`);
    return { ...item, group, image: asset(item.image, `${at} image`) };
  });
  for (const [i, item] of entries.entries()) {
    if (item.type !== 'message') continue;
    const previous = entries[i - 1];
    const next = entries[i + 1];
    if (['middle', 'end'].includes(item.group) && !(previous?.type === 'message'
      && previous.person === item.person && ['start', 'middle'].includes(previous.group))) {
      fail(`Message item ${i + 1}: ${item.group} needs a start or middle from the same person immediately before it.`);
    }
    if (['start', 'middle'].includes(item.group) && !(next?.type === 'message'
      && next.person === item.person && ['middle', 'end'].includes(next.group))) {
      fail(`Message item ${i + 1}: ${item.group} needs a middle or end from the same person immediately after it.`);
    }
  }

  const html = [];
  if (data.title?.trim()) html.push(`<h1>${escapeHTML(data.title)}</h1>`);
  if (data.dek?.trim()) html.push(`<p class="graphic-dek">${escapeHTML(data.dek)}</p>`);
  for (const item of entries) {
    if (item.type === 'note') {
      html.push(`<aside class="conversation-note" aria-label="Context">${escapeHTML(item.text)}</aside>`);
      continue;
    }
    if (item.type === 'divider') {
      html.push(`<p class="message-time-center">${escapeHTML(item.text)}</p>`);
      continue;
    }
    const person = people.get(item.person);
    const side = person.side;
    const showIdentity = ['solo', 'start'].includes(item.group);
    const portrait = person.headshot
      ? `<img class="headshot" src="${escapeHTML(person.headshot)}" alt="" />`
      : '<span class="headshot headshot-placeholder" aria-hidden="true"></span>';
    const name = showIdentity
      ? `<p class="message-name"${item.label ? ` data-label="${escapeHTML(item.label)}"` : ''}>${escapeHTML(person.name)}</p>` : '';
    const image = item.image ? `<img class="message-image" src="${escapeHTML(item.image)}" alt="${escapeHTML(item.image_alt)}" />` : '';
    const text = item.text ? `<p class="message-text">${escapeHTML(item.text)}</p>` : '';
    const time = item.time ? `<p class="message-time-${side}">${escapeHTML(item.time)}</p>` : '';
    const tail = asset(`images/mark_${side}.svg`, 'Bubble tail');
    const box = `<div class="message-box">${name}${image}${text}${time}<img class="mark_${side}" src="${tail}" alt="" /></div>`;
    html.push(`<div class="message-wrapper-${side} ${item.group}" role="group" aria-label="${escapeHTML(person.name)}">${side === 'left' ? portrait + box : box + portrait}</div>`);
  }
  if (data.note) html.push(`<p class="graphic-note">${escapeHTML(data.note)}</p>`);
  const source = [data.source, data.notes].filter(Boolean).map(escapeHTML).join(' • ');
  if (source) html.push(`<p id="graphicSource">${source}</p>`);
  return html.join('\n');
}


function documentHTML(data, styles, template, resolveAsset) {
  // Keep a compact inset below the top rule when there is no headline.
  // Add it at render time so restored project styles get the same treatment.
  const titlelessStyles = data.title?.trim() ? ''
    : '\nbody { margin-top: 0; padding-top: 10px; }\nmain > :first-child { margin-top: 0; }\n';
  const tokens = {
    '<!-- PAGE_TITLE -->': escapeHTML(data.title?.trim() || 'Text messages'),
    '/* STYLES */': styles + titlelessStyles,
    '<!-- CONTENT -->': render(data, resolveAsset)
  };
  for (const token of Object.keys(tokens)) {
    if (template.split(token).length !== 2) fail(`template.html must contain exactly one ${token} marker.`);
  }
  return template.replace(/<!-- PAGE_TITLE -->|\/\* STYLES \*\/|<!-- CONTENT -->/g, match => tokens[match]);
}
return { render, documentHTML, assetPath };
});
