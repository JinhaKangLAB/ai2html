# Text messages — editable project

This folder contains the source, local images and design used when Download all files was clicked.

## Continue editing — no Node or installation

Recommended: open your team's /exec editor, click Open project ZIP, and select
this ZIP as downloaded. Source, local images and design load together; you do
not need to unzip it. This also works with ZIPs saved by editor version 1.4.

Alternatively, use the included local editor:

1. Extract the entire ZIP before opening any files.
2. Double-click editor.html. The saved text, images and design load automatically.
3. Edit and preview. Download HTML to produce the finished graphic.
4. Click Download all files again to save a new editable handoff with your changes.

Browser edits do not overwrite this folder automatically. Keep the newest ZIP.
Reopening this editor starts from the snapshot in this folder. Open ArchieML can
load a newer content.aml; new images can be added under Images and design files.

## Files

- content.aml: the full editable source, including comments and optional people.
- graphics_messages.html: the finished graphic, with local images embedded.
- images/: all bundled and imported local image files, including unused ones.
- styles.css and template.html: the current graphic design.
- editor.html and its support files: the browser editor with this saved project.
- vendor/: the bundled ArchieML parser and its licenses.

External image URLs and the web font still need an internet connection. To carry
a remote picture in the project, obtain its image file, add it in the editor,
and use its images/filename path in the ArchieML before downloading again.

## Working with a shared Google Doc

This ZIP is a snapshot. It does not sync changes to your Google Doc or a published
graphic. If your team uses a shared source Doc, keep that Doc up to date too.
The local editor does not directly import Google Docs. In your team's /exec
editor, Open project ZIP restores this saved source and all its local assets.
To use newer copy from a Google Doc, open the ZIP first, then Load from Google
Doc; the restored images and design stay available. Add any new images that
were introduced after this snapshot. Loading is read-only and never updates the Doc.
Share the Doc link separately; this ZIP does not include account or access settings.
After edits, download a fresh HTML and replace the published graphic in your CMS.
