'use strict';
(() => {
  const defaults = window.TextMessageDefaults;
  const input = document.getElementById('aml');
  const frame = document.getElementById('preview');
  const status = document.getElementById('status');
  const saveHTML = document.getElementById('save-html');
  const saveAll = document.getElementById('save-all');
  let images = new Map(Object.entries(defaults.images));
  let styles = defaults.styles;
  let template = defaults.template;
  let revision = 0;
  let savedText = defaults.aml;
  let assetsDirty = false;
  let projectRequest = 0;
  let timer;

  function fail(error) {
    status.textContent = `Preview unavailable: ${error.message}`;
    status.className = 'error';
    saveHTML.disabled = true;
    saveAll.disabled = true;
    frame.srcdoc = '<!doctype html><html><body style="font:14px system-ui;padding:24px;color:#586675">Correct the ArchieML error to update the preview.</body></html>';
    frame.style.height = '220px';
  }
  function resolver(embed, assetImages = images) {
    return (normalized, location, original) => {
      if (/^https?:\/\//i.test(normalized)) return normalized;
      const key = original.replace(/^(\.\/)+/, '');
      if (!assetImages.has(key)) throw new Error(`${location}: add the file "${original}" using Add images, then use images/filename in the ArchieML.`);
      return embed ? assetImages.get(key) : normalized;
    };
  }
  function renderer() {
    const api = window.TextMessages;
    if (!api || typeof api.documentHTML !== 'function') {
      throw new Error('The editor renderer did not load. Replace the entire Index.html from the latest setup page, save, and deploy a new version.');
    }
    return api;
  }
  function parse() { return window.archieml.load(input.value); }
  function makeHTML(data, embed) { return renderer().documentHTML(data, styles, template, resolver(embed)); }
  function update() {
    clearTimeout(timer);
    try {
      const data = parse();
      frame.srcdoc = makeHTML(data, true);
      saveHTML.disabled = false;
      saveAll.disabled = !window.TextMessageProject || !window.TextMessageEditorFiles;
      status.className = '';
      const messages = data.messages.filter(item => item.type === 'message').length;
      const dividers = data.messages.filter(item => item.type === 'divider').length;
      const contextNotes = data.messages.filter(item => item.type === 'note').length;
      status.textContent = `Preview updated: ${messages} messages · ${dividers} date/time dividers · ${contextNotes} context notes.`;
    } catch (error) { fail(error); }
  }
  function changed() {
    revision++;
    clearTimeout(timer);
    saveHTML.disabled = true;
    saveAll.disabled = true;
    status.className = '';
    status.textContent = 'Updating preview…';
    timer = setTimeout(update, 300);
  }
  function download(name, text, mime) {
    const url = URL.createObjectURL(new Blob([text], { type: mime }));
    const link = document.createElement('a');
    link.href = url;
    link.download = name;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  input.value = defaults.aml;
  input.addEventListener('input', changed);
  const googleDocs = window.TextMessageGoogleDocs.setup({
    getRevision: () => revision,
    importText: (text, label) => {
      // Validate the text before replacing work. Local images can be added afterward.
      renderer().render(window.archieml.load(text), value => value);
      if (input.value !== savedText && input.value !== text && !window.confirm('Replace the changes in this editor with the Google Doc content? Cancel to download your ArchieML first.')) return false;
      revision++;
      input.value = text;
      savedText = text;
      document.getElementById('file-status').textContent = `Loaded ${label}. Edit the source Google Doc to keep its version history.`;
      update();
      return true;
    }
  });
  if (defaults.project) {
    document.getElementById('file-status').textContent = 'Project loaded with its saved content, local images and design.';
    document.getElementById('save-help').textContent = 'Download all files to save an updated editable project. Reopening this editor starts with the snapshot in this folder.';
    document.getElementById('embed-images').checked = true;
    document.getElementById('export-help').textContent = 'Local images are included in the HTML. Remote image URLs and the web font still need an internet connection.';
  }
  document.getElementById('update').addEventListener('click', update);
  document.getElementById('save-aml').addEventListener('click', () => {
    download('content.aml', input.value, 'text/plain;charset=utf-8');
    savedText = input.value;
    document.getElementById('file-status').textContent = 'ArchieML downloaded. Keep it as your saved editing file.';
  });
  saveHTML.addEventListener('click', () => {
    try {
      const embed = document.getElementById('embed-images').checked;
      const html = makeHTML(parse(), embed);
      download('graphics_messages.html', html, 'text/html;charset=utf-8');
      status.className = '';
      status.textContent = embed ? 'HTML downloaded with local images embedded.' : 'HTML downloaded. Save it beside your images folder.';
    } catch (error) { fail(error); }
  });
  saveAll.addEventListener('click', () => {
    try {
      const html = makeHTML(parse(), true);
      const blob = window.TextMessageProject.pack({
        aml: input.value, styles, template, images, html,
        editorFiles: window.TextMessageEditorFiles
      });
      download('text-messages-project.zip', blob, 'application/zip');
      savedText = input.value;
      assetsDirty = false;
      status.className = '';
      status.textContent = 'Project ZIP downloaded. Use Open project ZIP to restore it here, or unzip it and open editor.html.';
      document.getElementById('file-status').textContent = 'Editable project downloaded. Google Docs and published graphics are not updated by this download.';
    } catch (error) {
      status.className = 'error';
      status.textContent = 'Could not download project: ' + error.message;
    }
  });
  document.getElementById('open-project').addEventListener('change', async event => {
    const file = event.target.files[0];
    event.target.value = '';
    if (!file) return;
    const currentRequest = ++projectRequest;
    const requested = ++revision;
    const at = document.getElementById('project-status');
    const say = (message, error = false) => {
      at.hidden = false;
      at.className = error ? 'hint error' : 'hint';
      at.textContent = message;
    };
    say(`Opening ${file.name}…`);
    try {
      const next = await window.TextMessageProject.read(file);
      if (currentRequest !== projectRequest) return;
      if (requested !== revision) {
        say('Your editor changed while the ZIP was opening. Your changes are kept; select the ZIP again when ready.');
        return;
      }
      // Validate against the incoming assets before changing any current state.
      renderer().documentHTML(window.archieml.load(next.aml), next.styles, next.template, resolver(true, next.images));
      if ((input.value !== savedText || assetsDirty) && !window.confirm('Replace your unsaved text, images and design with this project ZIP? Cancel to Download all files first.')) {
        say('Project import cancelled. Your current graphic is unchanged.');
        return;
      }
      revision++;
      images = next.images;
      styles = next.styles;
      template = next.template;
      input.value = next.aml;
      savedText = next.aml;
      assetsDirty = false;
      googleDocs?.reset?.();
      document.getElementById('file-status').textContent = `Opened ${file.name} with its saved source, images and design.`;
      document.getElementById('image-status').textContent = `Restored ${images.size} local images from the project ZIP.`;
      document.getElementById('design-status').textContent = 'Restored the project styles and template.';
      document.getElementById('save-help').textContent = 'Download all files to save your next editable version. ZIP edits do not sync back to Google Docs.';
      document.getElementById('embed-images').checked = true;
      document.getElementById('embed-images').dispatchEvent(new Event('change'));
      update();
      say(`Project ready. ${images.size} local images loaded; no separate image upload is needed.`);
    } catch (error) {
      if (currentRequest === projectRequest) say(`Could not open project: ${error.message} Your current graphic is unchanged.`, true);
    }
  });
  document.getElementById('open-aml').addEventListener('change', async event => {
    const file = event.target.files[0];
    if (!file) return;
    const requested = ++revision;
    try {
      const text = await file.text();
      if (requested !== revision) return;
      input.value = text;
      savedText = text;
      document.getElementById('file-status').textContent = `Opened ${file.name}. Download ArchieML to keep your edits.`;
      update();
    } catch (error) { fail(error); }
    finally { event.target.value = ''; }
  });
  document.getElementById('open-images').addEventListener('change', async event => {
    const files = [...event.target.files];
    if (!files.length) return;
    const requested = ++revision;
    const at = document.getElementById('image-status');
    const added = [];
    const nextImages = new Map(images);
    try {
      for (const file of files) {
        if (!/^image\//.test(file.type)) throw new Error(`${file.name} is not a browser image file.`);
        const url = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
          reader.readAsDataURL(file);
        });
        const key = `images/${file.name}`;
        if (requested !== revision) return;
        nextImages.set(key, url);
        added.push(key);
      }
      images = nextImages;
      assetsDirty = true;
      revision++;
      at.textContent = `Added ${added.join(', ')}. Keep these files in images/ for exports without embedded images.`;
      update();
    } catch (error) { at.textContent = error.message; }
    finally { event.target.value = ''; }
  });
  document.getElementById('open-design').addEventListener('change', async event => {
    const files = [...event.target.files];
    if (!files.length) return;
    const requested = ++revision;
    const at = document.getElementById('design-status');
    let nextStyles = styles;
    let nextTemplate = template;
    try {
      for (const file of files) {
        if (file.name === 'styles.css') nextStyles = await file.text();
        else if (file.name === 'template.html') nextTemplate = await file.text();
        else throw new Error('Select files named styles.css and/or template.html.');
      }
      if (requested !== revision) return;
      renderer().documentHTML(parse(), nextStyles, nextTemplate, resolver(true));
      styles = nextStyles;
      template = nextTemplate;
      assetsDirty = true;
      revision++;
      at.textContent = 'Design loaded for this editing session.';
      update();
    } catch (error) { at.textContent = error.message; }
    finally { event.target.value = ''; }
  });
  document.getElementById('embed-images').addEventListener('change', event => {
    document.getElementById('export-help').textContent = event.target.checked
      ? 'Local images are included in the HTML. Remote image URLs and the web font still need an internet connection.'
      : 'Save the downloaded HTML beside your images folder.';
  });
  document.getElementById('preview-width').addEventListener('change', event => {
    frame.style.width = event.target.value === 'auto' ? '100%' : `${event.target.value}px`;
  });
  window.addEventListener('message', event => {
    const data = event.data;
    if (event.source !== frame.contentWindow || !data || data.sentinel !== 'amp'
      || data.type !== 'embed-size' || !Number.isFinite(data.height) || data.height < 0) return;
    frame.style.height = `${Math.ceil(data.height)}px`;
  });
  update();
})();
