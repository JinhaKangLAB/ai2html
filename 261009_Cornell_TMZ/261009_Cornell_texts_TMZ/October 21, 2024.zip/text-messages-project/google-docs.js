/* Google Apps Script transport. No credentials or document text are persisted. */
'use strict';
window.TextMessageGoogleDocs = {
  setup({ getRevision, importText }) {
    const byId = id => document.getElementById(id);
    const panel = byId('google-panel');
    const toggle = byId('open-google');
    const connected = Boolean(window.google?.script?.run);
    toggle.addEventListener('click', () => {
      panel.hidden = !panel.hidden;
      toggle.setAttribute('aria-expanded', String(!panel.hidden));
      if (!panel.hidden && connected) byId('google-url').focus();
    });
    if (!connected) return;
    byId('google-offline').hidden = true;
    byId('google-online').hidden = false;
    panel.hidden = false;
    toggle.setAttribute('aria-expanded', 'true');
    byId('file-status').textContent = 'Sample loaded. Paste your Google Doc link above to load your saved source.';
    byId('save-help').textContent = 'Keep tracked edits in your Google Doc. Download all files for an editable handoff with local images. Reopening this editor starts with the sample; load your Doc again to resume.';
    // A downloaded graphic should carry its local pictures when using the hosted editor.
    byId('embed-images').checked = true;
    byId('export-help').textContent = 'Local images are included in the HTML. Remote image URLs and the web font still need an internet connection.';

    const status = byId('google-status');
    const button = byId('load-google');
    const tabSelect = byId('google-tab');
    const tabRow = byId('google-tab-row');
    const sourceLink = byId('google-source');
    let loaded;
    let request = 0;
    let pendingTimeout;

    function say(message, error = false) {
      status.textContent = message;
      status.className = error ? 'hint error' : 'hint';
    }
    function useTab() {
      const tab = loaded?.tabs.find(item => item.id === tabSelect.value);
      if (!tab) return;
      try {
        if (tab.error) throw new Error(tab.error);
        if (!importText(tab.text, `${loaded.title} / ${tab.title}`)) {
          say('Import cancelled. Your editor content is unchanged.');
          return;
        }
        sourceLink.href = `https://docs.google.com/document/d/${encodeURIComponent(loaded.documentId)}/edit?tab=${encodeURIComponent(tab.id)}`;
        sourceLink.hidden = false;
        say(`Loaded ${loaded.title} / ${tab.title} at ${new Date(loaded.loadedAt).toLocaleTimeString()}. Signed in as ${loaded.email}. Check the preview below.`);
      } catch (error) {
        say(`Could not use this tab: ${error.message} Your editor content is unchanged.`, true);
      }
    }
    byId('use-google-tab').addEventListener('click', useTab);
    byId('google-form').addEventListener('submit', event => {
      event.preventDefault();
      const reference = byId('google-url').value.trim();
      if (!reference) return;
      const thisRequest = ++request;
      const requestedRevision = getRevision();
      button.disabled = true;
      byId('use-google-tab').disabled = true;
      say('Loading the latest saved content from Google Docs…');
      const timeout = setTimeout(() => {
        if (thisRequest !== request) return;
        request++;
        button.disabled = false;
        byId('use-google-tab').disabled = false;
        say('Google took too long to respond. Your content is unchanged. Check your connection and load again.', true);
      }, 45000);
      pendingTimeout = timeout;
      function finish() {
        clearTimeout(timeout);
        if (thisRequest !== request) return false;
        button.disabled = false;
        byId('use-google-tab').disabled = false;
        if (reference !== byId('google-url').value.trim()) {
          say('The Doc link changed while loading. Click Load Doc to use the new link.');
          return false;
        }
        return true;
      }
      window.google.script.run
        .withSuccessHandler(result => {
          if (!finish()) return;
          loaded = result;
          tabSelect.replaceChildren();
          for (const tab of result.tabs) {
            const option = document.createElement('option');
            option.value = tab.id;
            option.textContent = tab.title;
            tabSelect.append(option);
          }
          tabSelect.value = result.requestedTab || result.tabs[0].id;
          tabRow.hidden = false;
          if (requestedRevision !== getRevision()) {
            say('Your editor content changed while the Doc was loading. Choose Use selected tab when you are ready to replace it.');
          } else if (!result.requestedTab && result.tabs.length > 1) {
            say(`Found ${result.tabs.length} tabs in ${result.title}. Choose the tab containing your ArchieML, then click Use selected tab.`);
          } else useTab();
        })
        .withFailureHandler(error => {
          if (!finish()) return;
          loaded = undefined;
          tabRow.hidden = true;
          say(error?.message || 'Could not load the Doc. Check your account and Doc access, then try again.', true);
        })
        .readGoogleDoc(reference);
    });
    return {
      reset() {
        request++;
        clearTimeout(pendingTimeout);
        loaded = undefined;
        tabSelect.replaceChildren();
        tabRow.hidden = true;
        sourceLink.hidden = true;
        sourceLink.removeAttribute('href');
        byId('google-url').value = '';
        button.disabled = false;
        byId('use-google-tab').disabled = false;
        panel.hidden = true;
        toggle.setAttribute('aria-expanded', 'false');
        say('A project ZIP is loaded. Load a Google Doc here to switch sources.');
      }
    };
  }
};
